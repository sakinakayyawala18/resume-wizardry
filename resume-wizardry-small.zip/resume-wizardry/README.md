# Resume Wizardry

A lightweight, **client-only** (no server) resume builder focused on **ATS-friendly** output.
- Vite + React + Tailwind
- Live preview with 3 templates
- Export to **PDF** and **DOCX**
- Import/Export **JSON**
- Data is saved to **localStorage**

## Quickstart

```bash
npm i
npm run dev
```

Build for production:

```bash
npm run build
npm run preview
```

## Files
- `src/components/TemplatePicker.jsx` – choose templates
- `src/components/ResumeForm.jsx` – form inputs
- `src/components/ResumePreview.jsx` – printable preview
- `src/utils/exportToPDF.js` – HTML → PDF
- `src/utils/exportToDocx.js` – Data → DOCX (no tracking)

## Notes
- Everything runs locally in your browser. No API keys.
- For best PDF output, use the **Export PDF** button instead of the browser's print dialog.
