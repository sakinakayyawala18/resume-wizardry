import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

export async function exportToPdf(elementId, filename='resume.pdf'){
  const el = document.getElementById(elementId)
  if(!el) throw new Error('Element not found: '+elementId)

  const canvas = await html2canvas(el, { scale: 2, useCORS: true, backgroundColor: '#ffffff' })
  const imgData = canvas.toDataURL('image/png')
  const pdf = new jsPDF('p', 'mm', 'a4')
  const pdfWidth = pdf.internal.pageSize.getWidth()
  const pdfHeight = pdf.internal.pageSize.getHeight()

  // assume element is A4 sized in CSS (resume-page class); scale to fit
  pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight, '', 'FAST')
  pdf.save(filename)
}
