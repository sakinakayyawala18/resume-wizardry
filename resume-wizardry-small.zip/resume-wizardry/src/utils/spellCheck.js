// src/utils/spellCheck.js
import nspell from "nspell";

let spell = null;

async function loadText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to load ${url}: ${res.statusText}`);
  return await res.text();
}

export async function initSpellChecker() {
  if (spell) return;
  const [aff, dic] = await Promise.all([
    loadText("/dictionaries/en/index.aff"),
    loadText("/dictionaries/en/index.dic"),
  ]);
  spell = nspell(aff, dic);
}

export async function checkSpelling(text) {
  await initSpellChecker();
  const words = (text || "").split(/\s+/).filter(Boolean);
  const issues = [];
  for (const w of words) {
    const clean = w.replace(/[^a-zA-Z']/g, "");
    if (clean && !spell.correct(clean)) {
      issues.push({ word: clean, suggestions: spell.suggest(clean) });
    }
  }
  return issues;
}

/** NEW: check the entire resume data, return array of {path, word, suggestions} */
export async function checkResumeData(data) {
  await initSpellChecker();
  const out = [];

  async function run(text, path) {
    if (!text) return;
    const res = await checkSpelling(text);
    for (const r of res) out.push({ path, ...r });
  }

  const b = data?.basics || {};
  await run(b.fullName, "Basics → Full Name");
  await run(b.title, "Basics → Title");
  await run(b.email, "Basics → Email");
  await run(b.phone, "Basics → Phone");
  await run(b.location, "Basics → Location");
  await run(b.summary, "Basics → Summary");
  (b.links || []).forEach(async (l, i) => {
    await run(l?.label, `Links[${i}] → Label`);
    await run(l?.url, `Links[${i}] → URL`);
  });

  (data?.skills || []).forEach(async (s, i) => {
    await run(s?.name, `Skills[${i}]`);
  });

  (data?.experience || []).forEach(async (ex, i) => {
    await run(ex?.company, `Experience[${i}] → Company`);
    await run(ex?.role, `Experience[${i}] → Role`);
    await run(ex?.start, `Experience[${i}] → Start`);
    await run(ex?.end, `Experience[${i}] → End`);
    (ex?.bullets || []).forEach(async (t, j) =>
      await run(t, `Experience[${i}] → Bullet[${j}]`)
    );
  });

  (data?.projects || []).forEach(async (pr, i) => {
    await run(pr?.name, `Projects[${i}] → Name`);
    await run(pr?.link, `Projects[${i}] → Link`);
    (pr?.bullets || []).forEach(async (t, j) =>
      await run(t, `Projects[${i}] → Bullet[${j}]`)
    );
  });

  (data?.education || []).forEach(async (ed, i) => {
    await run(ed?.school, `Education[${i}] → School`);
    await run(ed?.degree, `Education[${i}] → Degree`);
    await run(ed?.start, `Education[${i}] → Start`);
    await run(ed?.end, `Education[${i}] → End`);
    (ed?.bullets || []).forEach(async (t, j) =>
      await run(t, `Education[${i}] → Bullet[${j}]`)
    );
  });

  (data?.achievements || []).forEach(async (a, i) =>
    await run(a, `Achievements[${i}]`)
  );

  // await all queued checks before returning (in case environment batches microtasks)
  await Promise.resolve();
  return out;
}
