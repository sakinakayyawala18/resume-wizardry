import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx'

function bullets(list){
  return list.map(t => new Paragraph({ text: t, bullet: { level: 0 } }))
}

export async function exportToDocx(data, template='clean'){
  const b = data.basics || {}
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({ text: b.fullName || '', heading: HeadingLevel.TITLE }),
        new Paragraph({ text: b.title || '' }),
        new Paragraph({ text: [b.email, b.phone, b.location].filter(Boolean).join(' • ') }),
        new Paragraph({ text: (b.links||[]).map(l=> `${l.label}: ${l.url}`).join(' • ') }),
        ...(b.summary ? [new Paragraph({ text: 'SUMMARY', heading: HeadingLevel.HEADING_2 }), new Paragraph({ text: b.summary })] : []),
        ...((data.skills||[]).length ? [new Paragraph({ text: 'SKILLS', heading: HeadingLevel.HEADING_2 }), new Paragraph({ text: (data.skills||[]).map(s=>s.name).join(' • ') })] : []),
        ...((data.experience||[]).length ? [
          new Paragraph({ text: 'EXPERIENCE', heading: HeadingLevel.HEADING_2 }),
          ...data.experience.flatMap(ex => [
            new Paragraph({ text: `${ex.role} — ${ex.company}` }),
            new Paragraph({ text: `${ex.start} – ${ex.end}` }),
            ...bullets(ex.bullets||[])
          ])
        ] : []),
        ...((data.projects||[]).length ? [
          new Paragraph({ text: 'PROJECTS', heading: HeadingLevel.HEADING_2 }),
          ...data.projects.flatMap(pr => [
            new Paragraph({ text: `${pr.name}${pr.link ? ' ('+pr.link+')' : ''}` }),
            ...bullets(pr.bullets||[])
          ])
        ] : []),
        ...((data.education||[]).length ? [
          new Paragraph({ text: 'EDUCATION', heading: HeadingLevel.HEADING_2 }),
          ...data.education.flatMap(ed => [
            new Paragraph({ text: `${ed.degree} — ${ed.school}` }),
            new Paragraph({ text: `${ed.start} – ${ed.end}` }),
            ...bullets(ed.bullets||[])
          ])
        ] : []),
        ...((data.achievements||[]).length ? [
          new Paragraph({ text: 'ACHIEVEMENTS', heading: HeadingLevel.HEADING_2 }),
          ...bullets(data.achievements||[])
        ] : []),
      ]
    }]
  })

  const blob = await Packer.toBlob(doc)
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'resume.docx'
  a.click()
  URL.revokeObjectURL(url)
}
