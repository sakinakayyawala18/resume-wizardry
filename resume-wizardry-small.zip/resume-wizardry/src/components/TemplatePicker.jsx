import React from 'react'

export default function TemplatePicker({ template, setTemplate, templates }){
  return (
    <div className="grid grid-cols-3 gap-3 mb-6">
      {templates.map(t => (
        <button
          key={t.id}
          onClick={() => setTemplate(t.id)}
          className={`border rounded-xl p-3 text-sm hover:bg-slate-50 ${template===t.id ? 'ring-2 ring-slate-400' : ''}`}
        >
          {t.name}
        </button>
      ))}
    </div>
  )
}
