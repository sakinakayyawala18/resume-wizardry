import React from "react";

export default function SpellCheckPanel({ issues = [], onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white w-[min(720px,92vw)] max-h-[80vh] overflow-auto rounded-2xl border p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-semibold">
            Spelling Issues ({issues.length})
          </h3>
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-sm border rounded-lg hover:bg-slate-50"
          >
            Close
          </button>
        </div>

        {issues.length === 0 ? (
          <div className="text-green-700 text-sm">No spelling mistakes 🎉</div>
        ) : (
          <ul className="space-y-2 text-sm">
            {issues.map((it, i) => (
              <li key={i} className="border rounded-lg p-2">
                <div className="font-medium">{it.word}</div>
                <div className="text-slate-600 text-xs mb-1">{it.path}</div>
                <div className="text-slate-700">
                  Suggestions: {it.suggestions?.join(", ") || "none"}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
