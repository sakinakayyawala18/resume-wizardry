import React from 'react'

function Section({title, children}){
  return (
    <div className="mb-4">
      <h3 className="text-sm font-semibold tracking-wide text-slate-700 mb-1">{title}</h3>
      <div className="space-y-1">{children}</div>
    </div>
  )
}

function Clean({data}){
  const b = data.basics||{}
  return (
    <div className="resume-page mx-auto text-[12px]">
      <div className="text-center mb-3">
        <div className="text-2xl font-bold">{b.fullName}</div>
        <div className="text-sm text-slate-600">{b.title}</div>
        <div className="text-xs text-slate-600 mt-1">
          {b.email} · {b.phone} · {b.location}
        </div>
        <div className="text-xs text-slate-600 mt-1 flex flex-wrap gap-2 justify-center">
          {(b.links||[]).map((l,i)=>(<span key={i}>{l.label}: {l.url}</span>))}
        </div>
      </div>

      {b.summary && (
        <Section title="SUMMARY">
          <p className="leading-snug">{b.summary}</p>
        </Section>
      )}

      {(data.skills||[]).length>0 && (
        <Section title="SKILLS">
          <p>{(data.skills||[]).map(s=>s.name).join(' · ')}</p>
        </Section>
      )}

      {(data.experience||[]).length>0 && (
        <Section title="EXPERIENCE">
          {(data.experience||[]).map((ex,idx)=>(
            <div key={idx}>
              <div className="font-semibold">{ex.role} — {ex.company}</div>
              <div className="text-xs text-slate-600 mb-1">{ex.start} – {ex.end}</div>
              <ul className="list-disc pl-5 leading-snug">
                {(ex.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
              </ul>
            </div>
          ))}
        </Section>
      )}

      {(data.projects||[]).length>0 && (
        <Section title="PROJECTS">
          {(data.projects||[]).map((pr,idx)=>(
            <div key={idx}>
              <div className="font-semibold">{pr.name} {pr.link && <span className="text-xs font-normal text-slate-600">({pr.link})</span>}</div>
              <ul className="list-disc pl-5 leading-snug">
                {(pr.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
              </ul>
            </div>
          ))}
        </Section>
      )}

      {(data.education||[]).length>0 && (
        <Section title="EDUCATION">
          {(data.education||[]).map((ed,idx)=>(
            <div key={idx}>
              <div className="font-semibold">{ed.degree} — {ed.school}</div>
              <div className="text-xs text-slate-600 mb-1">{ed.start} – {ed.end}</div>
              <ul className="list-disc pl-5 leading-snug">
                {(ed.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
              </ul>
            </div>
          ))}
        </Section>
      )}

      {(data.achievements||[]).length>0 && (
        <Section title="ACHIEVEMENTS">
          <ul className="list-disc pl-5 leading-snug">
            {(data.achievements||[]).map((a,i)=>(<li key={i}>{a}</li>))}
          </ul>
        </Section>
      )}
    </div>
  )
}

function Compact({data}){
  return <div className="resume-page mx-auto text-[11.5px]">
    <Clean data={data} />
  </div>
}

function Elegant({data}){
  const b = data.basics||{}
  return (
    <div className="resume-page mx-auto grid grid-cols-3 gap-6 text-[12px]">
      <div className="col-span-1 border-r pr-4">
        <div className="text-xl font-bold">{b.fullName}</div>
        <div className="text-sm text-slate-600">{b.title}</div>
        <div className="text-xs text-slate-600 mt-2 space-y-1">
          <div>{b.email}</div>
          <div>{b.phone}</div>
          <div>{b.location}</div>
        </div>
        <div className="mt-3">
          <h3 className="text-sm font-semibold tracking-wide text-slate-700 mb-1">SKILLS</h3>
          <ul className="list-disc pl-5">
            {(data.skills||[]).map((s,i)=>(<li key={i}>{s.name}</li>))}
          </ul>
        </div>
        {(b.links||[]).length>0 && (
          <div className="mt-3">
            <h3 className="text-sm font-semibold tracking-wide text-slate-700 mb-1">LINKS</h3>
            <ul className="list-disc pl-5">
              {(b.links||[]).map((l,i)=>(<li key={i}>{l.label}: {l.url}</li>))}
            </ul>
          </div>
        )}
      </div>
      <div className="col-span-2">
        {b.summary && (
          <Section title="SUMMARY">
            <p className="leading-snug">{b.summary}</p>
          </Section>
        )}
        {(data.experience||[]).length>0 && (
          <Section title="EXPERIENCE">
            {(data.experience||[]).map((ex,idx)=>(
              <div key={idx}>
                <div className="font-semibold">{ex.role} — {ex.company}</div>
                <div className="text-xs text-slate-600 mb-1">{ex.start} – {ex.end}</div>
                <ul className="list-disc pl-5 leading-snug">
                  {(ex.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
                </ul>
              </div>
            ))}
          </Section>
        )}
        {(data.projects||[]).length>0 && (
          <Section title="PROJECTS">
            {(data.projects||[]).map((pr,idx)=>(
              <div key={idx}>
                <div className="font-semibold">{pr.name} {pr.link && <span className="text-xs font-normal text-slate-600">({pr.link})</span>}</div>
                <ul className="list-disc pl-5 leading-snug">
                  {(pr.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
                </ul>
              </div>
            ))}
          </Section>
        )}
        {(data.education||[]).length>0 && (
          <Section title="EDUCATION">
            {(data.education||[]).map((ed,idx)=>(
              <div key={idx}>
                <div className="font-semibold">{ed.degree} — {ed.school}</div>
                <div className="text-xs text-slate-600 mb-1">{ed.start} – {ed.end}</div>
                <ul className="list-disc pl-5 leading-snug">
                  {(ed.bullets||[]).map((b,i)=>(<li key={i}>{b}</li>))}
                </ul>
              </div>
            ))}
          </Section>
        )}
      </div>
    </div>
  )
}

export default function ResumePreview({ id, data, template }){
  const T = template === 'clean' ? Clean : template==='compact' ? Compact : Elegant
  return (
    <div id={id} className="overflow-auto max-h-[80vh]">
      <T data={data} />
    </div>
  )
}
