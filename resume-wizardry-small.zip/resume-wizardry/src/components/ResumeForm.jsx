import React from 'react'
import { checkSpelling } from "../utils/spellCheck";   // <-- NEW

function TextInput({label, value, onChange, placeholder}){
  return (
    <label className="block mb-3">
      <div className="text-xs text-slate-600 mb-1">{label}</div>
      <input
        className="w-full border rounded-lg px-3 py-2"
        value={value}
        onChange={e=>onChange(e.target.value)}
        placeholder={placeholder}
      />
    </label>
  )
}

function TextArea({label, value, onChange, rows=3}){
  return (
    <label className="block mb-3">
      <div className="text-xs text-slate-600 mb-1">{label}</div>
      <textarea
        className="w-full border rounded-lg px-3 py-2"
        value={value}
        onChange={e=>onChange(e.target.value)}
        rows={rows}
      />
    </label>
  )
}

/* ---------- NEW BUTTON ---------- */
function SpellCheckButton({ text }) {
  const [issues, setIssues] = React.useState([]);

  async function run() {
    const result = await checkSpelling(text);
    setIssues(result);
    if (result.length === 0) alert("No spelling mistakes 🎉");
  }

  return (
    <div className="my-2">
      <button
        type="button"
        onClick={run}
        className="px-3 py-1 text-sm border rounded-lg hover:bg-slate-50"
      >
        Check Spelling
      </button>
      {issues.length > 0 && (
        <ul className="text-xs mt-1 text-red-600">
          {issues.map((m, i) => (
            <li key={i}>
              {m.word} → Suggestions: {m.suggestions.join(", ") || "none"}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
/* -------------------------------- */

export default function ResumeForm({ data, onChange }){
  const b = data.basics || {}
  const updateBasics = (patch)=> onChange({ basics: { ...b, ...patch } })

  const add = (key, item) => onChange({ [key]: [...(data[key]||[]), item] })
  const remove = (key, idx) => onChange({ [key]: (data[key]||[]).filter((_,i)=>i!==idx) })
  const updateItem = (key, idx, patch) => onChange({ [key]: (data[key]||[]).map((it,i)=> i===idx ? { ...it, ...patch } : it ) })

  return (
    <div>
      <h3 className="font-semibold mb-2">Basics</h3>
      <div className="grid md:grid-cols-2 gap-3">
        <TextInput label="Full Name" value={b.fullName||''} onChange={(v)=>updateBasics({fullName:v})} />
        <TextInput label="Title" value={b.title||''} onChange={(v)=>updateBasics({title:v})} />
        <TextInput label="Email" value={b.email||''} onChange={(v)=>updateBasics({email:v})} />
        <TextInput label="Phone" value={b.phone||''} onChange={(v)=>updateBasics({phone:v})} />
        <TextInput label="Location" value={b.location||''} onChange={(v)=>updateBasics({location:v})} />
      </div>

      <TextArea
        label="Professional Summary"
        value={b.summary||''}
        onChange={(v)=>updateBasics({summary:v})}
        rows={4}
      />
      <SpellCheckButton text={b.summary || ""} />   {/* <-- NEW */}

      <h3 className="font-semibold mt-6 mb-2">Links</h3>
      {(b.links||[]).map((link, idx)=> (
        <div key={idx} className="grid grid-cols-5 gap-2 items-end mb-2">
          <TextInput label="Label" value={link.label||''} onChange={(v)=>updateBasics({links: (b.links||[]).map((l,i)=> i===idx?{...l,label:v}:l)})} />
          <div className="col-span-3">
            <TextInput label="URL" value={link.url||''} onChange={(v)=>updateBasics({links: (b.links||[]).map((l,i)=> i===idx?{...l,url:v}:l)})} />
          </div>
          <button onClick={()=>updateBasics({links: (b.links||[]).filter((_,i)=>i!==idx)})} className="border rounded-lg px-3 py-2">Delete</button>
        </div>
      ))}
      <button onClick={()=>updateBasics({links:[...(b.links||[]), {label:'', url:''}]})} className="border rounded-lg px-3 py-2 mb-6">+ Add Link</button>

      <h3 className="font-semibold mb-2">Skills</h3>
      {(data.skills||[]).map((s, idx)=> (
        <div key={idx} className="grid grid-cols-3 gap-2 items-end mb-2">
          <TextInput label="Skill" value={s.name||''} onChange={(v)=>updateItem('skills', idx, {name:v})} />
          <TextInput label="Level (1-5)" value={s.level||''} onChange={(v)=>updateItem('skills', idx, {level:Number(v)})} />
          <button onClick={()=>remove('skills',idx)} className="border rounded-lg px-3 py-2">Delete</button>
        </div>
      ))}
      <button onClick={()=>add('skills', {name:'', level:3})} className="border rounded-lg px-3 py-2 mb-6">+ Add Skill</button>

      <h3 className="font-semibold mb-2">Experience</h3>
      {(data.experience||[]).map((ex, idx)=> (
        <div key={idx} className="border rounded-xl p-3 mb-2">
          <div className="grid md:grid-cols-2 gap-2">
            <TextInput label="Company" value={ex.company||''} onChange={(v)=>updateItem('experience', idx, {company:v})} />
            <TextInput label="Role" value={ex.role||''} onChange={(v)=>updateItem('experience', idx, {role:v})} />
            <TextInput label="Start (YYYY-MM)" value={ex.start||''} onChange={(v)=>updateItem('experience', idx, {start:v})} />
            <TextInput label="End (YYYY-MM or Present)" value={ex.end||''} onChange={(v)=>updateItem('experience', idx, {end:v})} />
          </div>
          <TextArea label="• Bullet 1\n• Bullet 2..." value={(ex.bullets||[]).join('\n')} onChange={(v)=>updateItem('experience', idx, {bullets: v.split('\n').filter(Boolean)})} rows={4} />
          <div className="flex justify-end">
            <button onClick={()=>remove('experience',idx)} className="border rounded-lg px-3 py-2">Delete</button>
          </div>
        </div>
      ))}
      <button onClick={()=>add('experience', {company:'', role:'', start:'', end:'', bullets:[]})} className="border rounded-lg px-3 py-2 mb-6">+ Add Experience</button>

      <h3 className="font-semibold mb-2">Projects</h3>
      {(data.projects||[]).map((pr, idx)=> (
        <div key={idx} className="border rounded-xl p-3 mb-2">
          <div className="grid md:grid-cols-2 gap-2">
            <TextInput label="Name" value={pr.name||''} onChange={(v)=>updateItem('projects', idx, {name:v})} />
            <TextInput label="Link" value={pr.link||''} onChange={(v)=>updateItem('projects', idx, {link:v})} />
          </div>
          <TextArea label="• Bullet 1\n• Bullet 2..." value={(pr.bullets||[]).join('\n')} onChange={(v)=>updateItem('projects', idx, {bullets: v.split('\n').filter(Boolean)})} rows={4} />
          <div className="flex justify-end">
            <button onClick={()=>remove('projects',idx)} className="border rounded-lg px-3 py-2">Delete</button>
          </div>
        </div>
      ))}
      <button onClick={()=>add('projects', {name:'', link:'', bullets:[]})} className="border rounded-lg px-3 py-2 mb-6">+ Add Project</button>

      <h3 className="font-semibold mb-2">Education</h3>
      {(data.education||[]).map((ed, idx)=> (
        <div key={idx} className="border rounded-xl p-3 mb-2">
          <div className="grid md:grid-cols-2 gap-2">
            <TextInput label="School" value={ed.school||''} onChange={(v)=>updateItem('education', idx, {school:v})} />
            <TextInput label="Degree" value={ed.degree||''} onChange={(v)=>updateItem('education', idx, {degree:v})} />
            <TextInput label="Start (YYYY-MM)" value={ed.start||''} onChange={(v)=>updateItem('education', idx, {start:v})} />
            <TextInput label="End (YYYY-MM)" value={ed.end||''} onChange={(v)=>updateItem('education', idx, {end:v})} />
          </div>
          <TextArea label="• Bullet 1\n• Bullet 2..." value={(ed.bullets||[]).join('\n')} onChange={(v)=>updateItem('education', idx, {bullets: v.split('\n').filter(Boolean)})} rows={3} />
          <div className="flex justify-end">
            <button onClick={()=>remove('education',idx)} className="border rounded-lg px-3 py-2">Delete</button>
          </div>
        </div>
      ))}
      <button onClick={()=>add('education', {school:'', degree:'', start:'', end:'', bullets:[]})} className="border rounded-lg px-3 py-2 mb-6">+ Add Education</button>

      <h3 className="font-semibold mb-2">Achievements</h3>
      <TextArea label="• One per line" value={(data.achievements||[]).join('\n')} onChange={(v)=>onChange({achievements: v.split('\n').filter(Boolean)})} rows={3} />
    </div>
  )
}
