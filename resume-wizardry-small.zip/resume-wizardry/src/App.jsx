import React, { useState } from 'react'
import { Wand2, Download, FileDown, Upload, FileText, LayoutTemplate, RotateCw } from 'lucide-react'
import TemplatePicker from './components/TemplatePicker.jsx'
import ResumeForm from './components/ResumeForm.jsx'
import ResumePreview from './components/ResumePreview.jsx'
import { exportToPdf } from './utils/exportToPDF.js'
import { exportToDocx } from './utils/exportToDocx.js'
import SpellCheckPanel from './components/SpellCheckPanel.jsx'
import { checkResumeData } from './utils/spellCheck.js'

const DEFAULT_DATA = {
  basics: {
    fullName: "",
    title: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
    links: []
  },
  skills: [],
  experience: [],
  projects: [
    { name: "", link: "", bullets: [] }
  ],
  education: [],
  achievements: []
}

const TEMPLATES = [
  { id: 'clean', name: 'Clean ATS' },
  { id: 'compact', name: 'Compact One-Page' },
  { id: 'elegant', name: 'Elegant Sidebar' },
]

export default function App() {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('rw:data')
    return saved ? JSON.parse(saved) : DEFAULT_DATA
  })
  const [template, setTemplate] = useState(() => localStorage.getItem('rw:template') || 'clean')

  // Spell-check panel state
  const [spellOpen, setSpellOpen] = useState(false)
  const [spellIssues, setSpellIssues] = useState([])

  const handleChange = (patch) => {
    const next = { ...data, ...patch }
    setData(next)
    localStorage.setItem('rw:data', JSON.stringify(next))
  }

  const reset = () => {
    setData(DEFAULT_DATA)
    setTemplate('clean')
    localStorage.removeItem('rw:data')
    localStorage.setItem('rw:template', 'clean')
  }

  const onExportPDF = async () => {
    const name = data?.basics?.fullName?.trim().replace(/\s+/g, '_') || 'export'
    await exportToPdf('resume-preview', `resume-${name}.pdf`)
  }

  const onExportDocx = async () => {
    await exportToDocx(data, template)
  }

  const onImport = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()
    try {
      const json = JSON.parse(text)
      setData(json)
      localStorage.setItem('rw:data', JSON.stringify(json))
      alert('Imported!')
    } catch {
      alert('Invalid JSON file.')
    }
  }

  const onExportJSON = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'resume-data.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  // NEW: run spell check across entire resume
  const onSpellCheckAll = async () => {
    try {
      const issues = await checkResumeData(data)
      setSpellIssues(issues)
      setSpellOpen(true)
    } catch (e) {
      alert('Spell check failed: ' + (e?.message || e))
    }
  }

  return (
    <div className="min-h-screen font-display">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <Wand2 className="size-6" />
          <h1 className="text-lg font-semibold">Resume Wizardry</h1>
          <span className="text-slate-500">Create ATS-optimized resumes fast</span>

          <div className="ml-auto flex gap-2">
            <button onClick={onSpellCheckAll} className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50">
              Check Spelling (All)
            </button>
            <button onClick={onExportPDF} className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50 flex items-center gap-2">
              <Download className="size-4" /> Export PDF
            </button>
            <button onClick={onExportDocx} className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50 flex items-center gap-2">
              <FileDown className="size-4" /> Export DOCX
            </button>
            <button onClick={onExportJSON} className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50 flex items-center gap-2">
              <FileText className="size-4" /> Export JSON
            </button>
            <label className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50 flex items-center gap-2 cursor-pointer">
              <Upload className="size-4" /> Import JSON
              <input onChange={onImport} type="file" accept="application/json" className="hidden" />
            </label>
            <button onClick={reset} className="px-3 py-2 text-sm rounded-xl border hover:bg-slate-50 flex items-center gap-2">
              <RotateCw className="size-4" /> Reset
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-6 p-4">
        <section className="bg-white border border-slate-200 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <LayoutTemplate className="size-5" />
            <h2 className="font-semibold">Template</h2>
          </div>
          <TemplatePicker
            template={template}
            setTemplate={(t) => { setTemplate(t); localStorage.setItem('rw:template', t) }}
            templates={TEMPLATES}
          />
          <ResumeForm data={data} onChange={handleChange} />
        </section>

        <section className="bg-slate-100 border border-slate-200 rounded-2xl p-4">
          <ResumePreview id="resume-preview" data={data} template={template} />
        </section>
      </main>

      <footer className="text-center text-xs text-slate-500 pb-8">
        Built locally — no server, no tracking.
      </footer>

      {spellOpen && (
        <SpellCheckPanel
          issues={spellIssues}
          onClose={() => setSpellOpen(false)}
        />
      )}
    </div>
  )
}
